package org.example;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class FileStat {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] wordArray = new String[20]; // 用于存储输入的单词列表
        String input; // 用户的输入
        String inputFilePath = "src/main/resources/words.txt";
        String outputFilePath = "src/main/resources/wordStat.txt";
        // 你的代码逻辑



    }
}