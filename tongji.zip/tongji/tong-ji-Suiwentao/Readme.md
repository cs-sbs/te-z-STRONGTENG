[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/_m9rGUgO)
## 基于流的文件信息统计（请在org.example.FileStat中回答该题目）


本次作业旨在让同学们熟悉使用 FileInputStream 和 FileOutputStream（或其子类）进行文件的读取与写入操作，
并通过对给定单词列表文件的处理，统计特定单词作为独立词出现的数量，最后将统计结果写入到指定的输出文件中。


读取在**resources**路径下的words.txt文件，该文件中包含一系列的单词，单词之间以空格、标点符号（如逗号、句号、问号、感叹号等）或换行符分隔。
用户从控制台中输入需要统计的单词（例如："apple"、"book"、"cat" 等，可以是多个）。要求能够准确识别这些特定单词作为独立词在输入文件中的出现次数，
不考虑其在其他单词内部的情况。例如，在 "This is an apple tree." 中，
"apple" 作为独立词出现了 1 次。


**输入格式**:
每行一个单词，单词列表的最大长度为20，如果输入-1则表示输入结束。

**输出格式**:
按输入顺序每行一个单词，然后跟上一个冒号和该单词的统计数量

### 输入样例：
```
beans
-1
```

### 输出文件内容样例：
```
beans:10
```




### 输入样例：
```
purposes
used
sun
-1
```

### 输出文件内容样例：
```
purposes:1
used:53
sun:1
```



###  时间限制：500ms内存限制：32000kb
